﻿You can freely use PasswordFinder, but it should not be used for anything other than educational purposes.
That's it, I saved the face. I put the text that will protect me. The honor is safe, even if all that is the can.

PasswordFinder is written in 'C' language. It is offered in freeware. That's all.

It can not replace tools as powerful as John The Ripper, Cain and Abel ... But it is another tool.

PasswordFinder is a tool for generating hash keys as password functions.
It has several alphabets. It is able to generate passwords of length 1 to 16 characters.
It can import password lists or search for a password by providing its hash key.
Do not think you can hack anyone and anything with this program. You need to have hash keys.

To get there it was necessary to recover these keys from a user. There are several ways to recover them.

	1 - Install a keylogger, Virus, which will automatically transfer keystrokes.
	2 - During an internet session to position itself between the user and the sites he visits (Man in the Middle).
	3 - Using a tool like WireShark, capture the user's session.
	4 - Have the user come to your website and offer to test the strength of their passwords.
	5 - Call the user, Phishing, and ask him to change his passwords.

The list can not be exhaustive, but serves for understanding.

PasswordFinder stores its data in SQLite tables accessible by any database software.

The algorithms of PasswordFinder:
---------------------------------

  1 - Abacus (128 bits)
  2 - Abacus (160 bits)
  3 - Abacus (192 bits)
  4 - Abacus (224 bits)
  5 - Abacus (256 bits)
  6 - Abacus (384 bits)
  7 - Abacus (512 bits)
  8 - Abacus (1024 bits)
  9 - AriRang (224 bits)
 10 - AriRang (256 bits)
 11 - AriRang (384 bits)
 12 - AriRang (512 bits)
 13 - Aurora (224 bits)
 14 - Aurora (256 bits)
 15 - Aurora (384 bits)
 16 - Aurora (512 bits)
 17 - Blake (224 bits)
 18 - Blake (256 bits)
 19 - Blake (384 bits)
 20 - Blake (512 bits)
 21 - Blender (192 bits)
 22 - Blender (224 bits)
 23 - Blender (256 bits)
 24 - Blender (288 bits)
 25 - Blender (320 bits)
 26 - Blender (384 bits)
 27 - Blender (448 bits)
 28 - Blender (512 bits)
 29 - Blender (576 bits)
 30 - Blender (640 bits)
 31 - Bmw (224 bits)
 32 - Bmw (256 bits)
 33 - Bmw (384 bits)
 34 - Bmw (512 bits)
 35 - Boole (224 bits)
 36 - Boole (256 bits)
 37 - Boole (384 bits)
 38 - Boole (512 bits)
 39 - Cheetah (224 bits)
 40 - Cheetah (256 bits)
 41 - Cheetah (384 bits)
 42 - Cheetah (512 bits)
 43 - Crunch (224 bits)
 44 - Crunch (256 bits)
 45 - Crunch (384 bits)
 46 - Crunch (512 bits)
 47 - CubeHash (224 bits)
 48 - CubeHash (256 bits)
 49 - CubeHash (384 bits)
 50 - CubeHash (512 bits)
 51 - Echo (224 bits)
 52 - Echo (256 bits)
 53 - Echo (384 bits)
 54 - Echo (512 bits)
 55 - Fugue (224 bits)
 56 - Fugue (256 bits)
 57 - Fugue (384 bits)
 58 - Fugue (512 bits)
 59 - Grøstl (224 bits)
 60 - Grøstl (256 bits)
 61 - Grøstl (384 bits)
 62 - Grøstl (512 bits)
 63 - Hamsi (224 bits)
 64 - Hamsi (256 bits)
 65 - Hamsi (384 bits)
 66 - Hamsi (512 bits)
 67 - Haval_3 (128 bits)
 68 - Haval_3 (160 bits)
 69 - Haval_3 (192 bits)
 70 - Haval_3 (224 bits)
 71 - Haval_3 (256 bits)
 72 - Haval_4 (128 bits)
 73 - Haval_4 (160 bits)
 74 - Haval_4 (192 bits)
 75 - Haval_4 (224 bits)
 76 - Haval_4 (256 bits)
 77 - Haval_5 (128 bits)
 78 - Haval_5 (160 bits)
 79 - Haval_5 (192 bits)
 80 - Haval_5 (224 bits)
 81 - Haval_5 (256 bits)
 82 - Jh (224 bits)
 83 - Jh (256 bits)
 84 - Jh (384 bits)
 85 - Jh (512 bits)
 86 - Keccak (224 bits)
 87 - Keccak (256 bits)
 88 - Keccak (384 bits)
 89 - Keccak (512 bits)
 90 - Luffa (224 bits)
 91 - Luffa (256 bits)
 92 - Luffa (384 bits)
 93 - Luffa (512 bits)
 94 - Maraca (128 bits)
 95 - Md 2 (128 bits)
 96 - Md 4 (128 bits)
 97 - Md 5 (128 bits)
 98 - Md 5(Sha1) (128 bits)
 99 - Md 6 (128 bits)
100 - Md 6 (160 bits)
101 - Md 6 (192 bits)
102 - Md 6 (224 bits)
103 - Md 6 (256 bits)
104 - Md 6 (384 bits)
105 - Md 6 (512 bits)
106 - Panama (256 bits)
107 - RadioGatun (256 bits)
108 - RadioGatun (64 bits)
109 - RipeMd (128 bits)
110 - RipeMd (160 bits)
111 - Sarmal (224 bits)
112 - Sarmal (256 bits)
113 - Sarmal (384 bits)
114 - Sarmal (512 bits)
115 - Sha 0 (160 bits)
116 - Sha 1 (160 bits)
117 - Sha 1(Md 5) (160 bits)
118 - Sha 1(Sha1) (160 bits)
119 - Sha 2 (224 bits)
120 - Sha 2 (256 bits)
121 - Sha 2 (384 bits)
122 - Sha 2 (512 bits)
123 - Shabal (192 bits)
124 - Shabal (224 bits)
125 - Shabal (256 bits)
126 - Shabal (384 bits)
127 - Shabal (512 bits)
128 - Shamata (224 bits)
129 - Shamata (256 bits)
130 - Shamata (384 bits)
131 - Shamata (512 bits)
132 - Shavite (224 bits)
133 - Shavite (256 bits)
134 - Shavite (384 bits)
135 - Shavite (512 bits)
136 - Simd (224 bits)
137 - Simd (256 bits)
138 - Simd (384 bits)
139 - Simd (512 bits)
140 - Skein (224 bits)
141 - Skein (256 bits)
142 - Skein (384 bits)
143 - Skein (512 bits)
144 - Stream Hash (224 bits)
145 - Stream Hash (256 bits)
146 - Stream Hash (384 bits)
147 - Stream Hash (512 bits)
148 - Tiger (192 bits)
149 - Waterfall (512 bits)
150 - Whirlpool (512 bits)

The alphabets of PasswordFinder:
--------------------------------

 " !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "+-*/%"
 "-."
 "01 !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "01"
 "01+-*/%"
 "01-."
 "0123456789 !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "0123456789"
 "0123456789+-*/%"
 "0123456789-."
 "ABCDEFGHIJKLMNOPQRSTUVWXYZ !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
 "ABCDEFGHIJKLMNOPQRSTUVWXYZ+-*/%"
 "ABCDEFGHIJKLMNOPQRSTUVWXYZ-."
 "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
 "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+-*/%"
 "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-."
 "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
 "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz+-*/%"
 "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-."
 "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
 "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-*/%"
 "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-."
 "AEIOUY !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "AEIOUY"
 "AEIOUY+-*/%"
 "AEIOUY-."
 "AEIOUY01 !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "AEIOUY01"
 "AEIOUY01+-*/%"
 "AEIOUY01-."
 "AEIOUYaeiouy !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "AEIOUYaeiouy"
 "AEIOUYaeiouy+-*/%"
 "AEIOUYaeiouy-."
 "AEIOUYaeiouy01 !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "AEIOUYaeiouy01"
 "AEIOUYaeiouy01+-*/%"
 "AEIOUYaeiouy01-."
 "BCDFGHJKLMNPQRSTVWXZ !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "BCDFGHJKLMNPQRSTVWXZ"
 "BCDFGHJKLMNPQRSTVWXZ+-*/%"
 "BCDFGHJKLMNPQRSTVWXZ-."
 "BCDFGHJKLMNPQRSTVWXZ01 !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "BCDFGHJKLMNPQRSTVWXZ01"
 "BCDFGHJKLMNPQRSTVWXZ01+-*/%"
 "BCDFGHJKLMNPQRSTVWXZ01-."
 "BCDFGHJKLMNPQRSTVWXZbcdfghjklmnpqrstvwxz !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "BCDFGHJKLMNPQRSTVWXZbcdfghjklmnpqrstvwxz"
 "BCDFGHJKLMNPQRSTVWXZbcdfghjklmnpqrstvwxz+-*/%"
 "BCDFGHJKLMNPQRSTVWXZbcdfghjklmnpqrstvwxz-."
 "BCDFGHJKLMNPQRSTVWXZbcdfghjklmnpqrstvwxz01 !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "BCDFGHJKLMNPQRSTVWXZbcdfghjklmnpqrstvwxz01"
 "BCDFGHJKLMNPQRSTVWXZbcdfghjklmnpqrstvwxz01+-*/%"
 "BCDFGHJKLMNPQRSTVWXZbcdfghjklmnpqrstvwxz01-."
 "abcdefghijklmnopqrstuvwxyz !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "abcdefghijklmnopqrstuvwxyz"
 "abcdefghijklmnopqrstuvwxyz+-*/%"
 "abcdefghijklmnopqrstuvwxyz-."
 "abcdefghijklmnopqrstuvwxyz0123456789 !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "abcdefghijklmnopqrstuvwxyz0123456789"
 "abcdefghijklmnopqrstuvwxyz0123456789+-*/%"
 "abcdefghijklmnopqrstuvwxyz0123456789-."
 "aeiouy !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "aeiouy"
 "aeiouy+-*/%"
 "aeiouy-."
 "aeiouy01 !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "aeiouy01"
 "aeiouy01+-*/%"
 "aeiouy01-."
 "bcdfghjklmnpqrstvwxz !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "bcdfghjklmnpqrstvwxz"
 "bcdfghjklmnpqrstvwxz+-*/%"
 "bcdfghjklmnpqrstvwxz-."
 "bcdfghjklmnpqrstvwxz01 !\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~£¤§¨°²µ€"
 "bcdfghjklmnpqrstvwxz01"
 "bcdfghjklmnpqrstvwxz01+-*/%"
 "bcdfghjklmnpqrstvwxz01-."

The functions of PasswordFinder:
---------------------------------

1 - Automatically generate passwords from 1 to 16 characters long. During generation, recovery points
are created. It is therefore possible to stop a generation at any time.

2 - Import a list of passwords. The import file must be in text format and must include a password
by line. The file can have the extension txt or csv, it does not matter. The lines must be separated by a
CRLF (Carriage Return & Line Feed), Windows format and not by a LF (Line Feed) penguin format. Files must be encoded in ANSI format.

3 - Manually insert a password.

4 - Search for a password by providing the hash key.

Others:
--------

For some operations, there are two modes of operation:

1 - The "Background" mode: The operations are carried out in the background thus making it possible to use the computer without
to be penalized too much.

2 - The "Foreground" mode: Operations are done in the foreground, making the use of other software slower.
This still has the advantage of making PasswordFinder faster, that's the main thing.

In early versions of the software, I stored 16,000,000 passwords per table, which was a feat. Combining speed and storage with
SQLITE seemed like a feat.

But it was not counting on the flip side, when SQLite reorganized the tables, orders "VACUUM", it was very very long.
The other disadvantage, more annoying that one, prevented a search of password through files.
So I reduced the number of passwords stored at 500 000. Obviously, the tables are much more numerous,
but the researches are greatly improved.

Sometimes it is useful to combine several alphabets to generate passwords. The new alphabet is composed of
two subsets. Example: Lowercase letters and Numbers.

The main disadvantage of this alphabet is that it generates too many combinations. Let's imagine that numbers combinations
have already been created. Same for lowercase letters.

So the new alphabet will create three types of combinations:

	1 - The lowercase letters
	2 - The numbers
	3 - Lowercase letters and numbers

I've included a new rule: When an alphabet is composed of subsets, the program only generates the combinations
covering all subsets at the same time. In the example above, the program will eliminate points 1 and 2 to
keep that point 3.

There are now 375 alphabets representing all possible combinations of alphabets.

In these alphabets you will not find:

	Numbers & Binary
	Signs & Operators
	Signs & Morse
	Lowercase letters & lowercase vowels
	Uppercase letters & uppercase vowels
	Lowercase letters & lowercase consonants
	Uppercase letters & uppercase consonants

Also, a new rule has been introduced: When an alphabet is included in another larger one, it is not created.
